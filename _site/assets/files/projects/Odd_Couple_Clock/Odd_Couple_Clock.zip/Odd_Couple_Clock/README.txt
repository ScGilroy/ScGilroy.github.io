Odd Couple Clock
Created by Scott Gilroy
Last Update: 11/19/2020

Bill of Materials:
	• 5mm White LED x 21
	• 5mm Blue LED x 1
	• 5mm Red LED x 1
	• 220 Ohm Resistor x 6
	• Ardiuno Nano 
	• Adafruit DS3231 RTC Module
	• 24x18 Prototyping Board
	• Female Dupoint Connectors
	• Male-Male Dupoint Wires


3D Model:
	• Both parts can be printed without supports
	• Successful bridging is needed to print the LED holes in Face.stl
	• Face.stl was printed in PLA due to the many detailed features (on a Ender 3 Pro).
	• Frame.stl was printed in PETG at the same time (on a Prusa MK3s).

Schematic:
	• LEDs negative pin are soldered together in groups of 6 then half a dupoint wire is soldered and connected to the arduino nano pins.
	• Positive pins were soldered to half a Male-Male Dupoint wire then connected to the Prototyping Board.
	• A small wire then connects the prototyping board to the arduino

Code:
	• The blink code was used to determine LEDiter which is a 4x7 matrix which maps the LED to the boolean value.
	• LEDbool is vector of 24 digits which features 
		• 0 to 11  : Hour LEDs
		• 12       : AM/PM
		• 13 to 17 : 10 Minutes
		• 18	   : 5 Minutes
		• 19 to 22 : 1 Minutes
		• 24	   : Unused (But can be addressed)
	• Depending on how the pins are soldered, use the blink example to determine and match the correct pin address to the correct boolean values.